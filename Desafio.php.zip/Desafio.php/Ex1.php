<?php
$num1= 55;
$num2 = 20;

$soma = $num1 + $num2;
echo "A soma do $num1 e $num2 é: $soma"
?>