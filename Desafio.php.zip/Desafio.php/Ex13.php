<?php
for ($numero = 1; $numero <= 100; $i++) {
     $soma += $i;
}
echo "A soma dos numeros de 1 ate 100 é: $soma";
?>